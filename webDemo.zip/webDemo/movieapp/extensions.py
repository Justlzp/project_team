__author__ = 'Guo'

from flask_bcrypt import Bcrypt
from flask_login import LoginManager

login_manager = LoginManager()
bcrypt = Bcrypt()